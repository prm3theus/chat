import React, { useEffect, useState } from 'react';
import logo from './logo.svg';
import './App.css';
import { Fluence, KeyPair } from '@fluencelabs/fluence'
import { krasnodar } from "@fluencelabs/fluence-network-environment";
// import { registerChatServer, makeAck } from './generated/Chat'
import { addMessage } from './generated_aqua/reed'
// import { getRelayTime } from "./generated/reed";
import { setMaxListeners } from 'events';
import { setMaxIdleHTTPParsers } from 'http';
// import { createClient, configureChains, mainnet } from 'wagmi'
// import { publicProvider } from 'wagmi/providers/public'
// import { InjectedConnector } from 'wagmi/connectors/injected'
import { ethers } from 'ethers'

// import { useConnect, useAccount } from 'wagmi'
// import { InjectedConnector } from 'wagmi/connectors/injected'
import { unstable_runWithPriority } from 'scheduler';
import { PROPERTY_TYPES } from '@babel/types';
// import HorizontalScroll from 'react-horizontal-scrolling'

const Arena = require('are.na')


const ob = require('urbit-ob')

const eclipticABI = [{"constant":true,"inputs":[{"name":"_interfaceId","type":"bytes4"}],"name":"supportsInterface","outputs":[{"name":"","type":"bool"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[{"name":"_galaxy","type":"uint8"},{"name":"_proposal","type":"bytes32"}],"name":"startDocumentPoll","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":true,"inputs":[],"name":"name","outputs":[{"name":"","type":"string"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[{"name":"_point","type":"uint32"}],"name":"detach","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":true,"inputs":[{"name":"_tokenId","type":"uint256"}],"name":"getApproved","outputs":[{"name":"approved","type":"address"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[{"name":"_approved","type":"address"},{"name":"_tokenId","type":"uint256"}],"name":"approve","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":false,"inputs":[{"name":"_proposal","type":"bytes32"}],"name":"updateDocumentPoll","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":false,"inputs":[],"name":"onUpgrade","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":true,"inputs":[],"name":"InterfaceId_ERC165","outputs":[{"name":"","type":"bytes4"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[{"name":"_point","type":"uint32"},{"name":"_target","type":"address"},{"name":"_reset","type":"bool"}],"name":"transferPoint","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":false,"inputs":[{"name":"_from","type":"address"},{"name":"_to","type":"address"},{"name":"_tokenId","type":"uint256"}],"name":"transferFrom","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":false,"inputs":[{"name":"_galaxy","type":"uint8"},{"name":"_target","type":"address"}],"name":"createGalaxy","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":true,"inputs":[],"name":"depositAddress","outputs":[{"name":"","type":"address"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[{"name":"_point","type":"uint32"},{"name":"_transferProxy","type":"address"}],"name":"setTransferProxy","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":true,"inputs":[],"name":"treasuryUpgradeHash","outputs":[{"name":"","type":"bytes32"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[{"name":"_from","type":"address"},{"name":"_to","type":"address"},{"name":"_tokenId","type":"uint256"}],"name":"safeTransferFrom","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":false,"inputs":[{"name":"_point","type":"uint32"},{"name":"_encryptionKey","type":"bytes32"},{"name":"_authenticationKey","type":"bytes32"},{"name":"_cryptoSuiteVersion","type":"uint32"},{"name":"_discontinuous","type":"bool"}],"name":"configureKeys","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":true,"inputs":[{"name":"_point","type":"uint32"},{"name":"_sponsor","type":"uint32"}],"name":"canEscapeTo","outputs":[{"name":"canEscape","type":"bool"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[{"name":"_treasuryImpl","type":"address"}],"name":"upgradeTreasury","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":true,"inputs":[{"name":"_tokenId","type":"uint256"}],"name":"exists","outputs":[{"name":"doesExist","type":"bool"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[{"name":"_galaxy","type":"uint8"},{"name":"_proposal","type":"address"},{"name":"_vote","type":"bool"}],"name":"castUpgradeVote","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":false,"inputs":[{"name":"_proposal","type":"address"}],"name":"updateUpgradePoll","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":true,"inputs":[],"name":"treasuryProxy","outputs":[{"name":"","type":"address"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[{"name":"_tokenId","type":"uint256"}],"name":"ownerOf","outputs":[{"name":"owner","type":"address"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[{"name":"_galaxy","type":"uint8"},{"name":"_proposal","type":"bytes32"},{"name":"_vote","type":"bool"}],"name":"castDocumentVote","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":true,"inputs":[{"name":"_owner","type":"address"}],"name":"balanceOf","outputs":[{"name":"balance","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[],"name":"renounceOwnership","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":false,"inputs":[{"name":"_point","type":"uint32"},{"name":"_manager","type":"address"}],"name":"setManagementProxy","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":true,"inputs":[],"name":"owner","outputs":[{"name":"","type":"address"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[],"name":"symbol","outputs":[{"name":"","type":"string"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[],"name":"treasuryUpgraded","outputs":[{"name":"","type":"bool"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[{"name":"_galaxy","type":"uint8"},{"name":"_proposal","type":"address"}],"name":"startUpgradePoll","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":false,"inputs":[{"name":"_point","type":"uint32"},{"name":"_target","type":"address"}],"name":"spawn","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":false,"inputs":[{"name":"_operator","type":"address"},{"name":"_approved","type":"bool"}],"name":"setApprovalForAll","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":false,"inputs":[{"name":"_galaxy","type":"uint8"},{"name":"_voter","type":"address"}],"name":"setVotingProxy","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":false,"inputs":[{"name":"_prefix","type":"uint16"},{"name":"_spawnProxy","type":"address"}],"name":"setSpawnProxy","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":false,"inputs":[{"name":"_from","type":"address"},{"name":"_to","type":"address"},{"name":"_tokenId","type":"uint256"},{"name":"_data","type":"bytes"}],"name":"safeTransferFrom","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":false,"inputs":[{"name":"_primary","type":"string"},{"name":"_secondary","type":"string"},{"name":"_tertiary","type":"string"}],"name":"setDnsDomains","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":false,"inputs":[{"name":"_point","type":"uint32"}],"name":"reject","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":false,"inputs":[{"name":"_point","type":"uint32"},{"name":"_sponsor","type":"uint32"}],"name":"escape","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":false,"inputs":[{"name":"_point","type":"uint32"}],"name":"adopt","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":false,"inputs":[{"name":"_point","type":"uint32"}],"name":"cancelEscape","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":true,"inputs":[{"name":"_tokenId","type":"uint256"}],"name":"tokenURI","outputs":[{"name":"_tokenURI","type":"string"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[],"name":"azimuth","outputs":[{"name":"","type":"address"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[],"name":"claims","outputs":[{"name":"","type":"address"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[],"name":"polls","outputs":[{"name":"","type":"address"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[{"name":"_owner","type":"address"},{"name":"_operator","type":"address"}],"name":"isApprovedForAll","outputs":[{"name":"result","type":"bool"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[],"name":"previousEcliptic","outputs":[{"name":"","type":"address"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[{"name":"_point","type":"uint32"},{"name":"_time","type":"uint256"}],"name":"getSpawnLimit","outputs":[{"name":"limit","type":"uint32"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[{"name":"_newOwner","type":"address"}],"name":"transferOwnership","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"inputs":[{"name":"_previous","type":"address"},{"name":"_azimuth","type":"address"},{"name":"_polls","type":"address"},{"name":"_claims","type":"address"},{"name":"_treasuryProxy","type":"address"}],"payable":false,"stateMutability":"nonpayable","type":"constructor"},{"anonymous":false,"inputs":[{"indexed":true,"name":"_from","type":"address"},{"indexed":true,"name":"_to","type":"address"},{"indexed":true,"name":"_tokenId","type":"uint256"}],"name":"Transfer","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"name":"_owner","type":"address"},{"indexed":true,"name":"_approved","type":"address"},{"indexed":true,"name":"_tokenId","type":"uint256"}],"name":"Approval","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"name":"_owner","type":"address"},{"indexed":true,"name":"_operator","type":"address"},{"indexed":false,"name":"_approved","type":"bool"}],"name":"ApprovalForAll","type":"event"},{"anonymous":false,"inputs":[{"indexed":false,"name":"to","type":"address"}],"name":"Upgraded","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"name":"previousOwner","type":"address"}],"name":"OwnershipRenounced","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"name":"previousOwner","type":"address"},{"indexed":true,"name":"newOwner","type":"address"}],"name":"OwnershipTransferred","type":"event"}]

// import library from './talis.js'

// import { send } from 'q';
// const Matter = require('./matter.direct/index_className')
// receive a message from the server

const socket = new WebSocket("ws://localhost:3001");

// import { io } from "socket.io-client";
let count = 0
const PEER_ID ='12D3KooWFk99iv8UcbPjYXavVhXs6SFCAeqF7RFzgUam1n8k19sQ' // federated
const RELAY_ZONE=6
const library: any = {
  0: '🃟',
  1: '⚚',
  2: '♕',
  3: '⚘',
  4: '♖',
  5: '♔',
  6: '☂',
  7: '♘',
  8: '☮',
  9: '☯',
  10: '☸',
  11: '⚖',
  12: '♱',
  13: '☠',
  14: '♻',
  15: '☢',
  16: '☖',
  17: '★',
  18: '☽',
  19: '☼',
  20: '⚱',
  21: '⚬',
  22: '∅',
  23: 'RED',
  24: 'ORANGE',
  25: 'YELLOW',
  26: 'GREEN',
  27: 'CYAN',
  28: '◨',
  29: '❍',
  30: '∞',
  31: '☉',
  32: '☿',
  33: '♀',
  34: '♁',
  35: '♂',
  36: '♃',
  37: '♄',
  38: '♅',
  39: '♆',
  40: '♇',
  41: '⚀',
  42: 'Birch 𐂷 BEITH',
  43: 'Rowan 𐂷 LUIS',
  44: 'Alder 𐂷 FEARN',
  45: 'Willow 𐂷 SAILLE',
  46: 'Ash 𐂷 NUIN',
  47: 'Hawthon 𐂷 HUATHE',
  48: 'Oak 𐂷 DUIR',
  49: 'Holly 𐂷 TINNE',
  50: 'Hazel 𐂷 COLL',
  51: 'Apple 𐂷 QUERT',
  52: 'Vine 𐂷 MUIN',
  53: 'Ivy 𐂷 GORT',
  54: 'Reed 𐂷 NGETAL',
  55: 'Blackthorn 𐂷 STRAIF',
  56: 'Elder 𐂷 RUIS',
  57: 'Silver Fir 𐂷 AILIM',
  58: 'Furze 𐂷 OHN',
  59: 'Heather 𐂷 UR',
  60: 'Poplar 𐂷 EADHA',
  61: 'Yew 𐂷 IOHO',
  62: 'The Grove 𐂷 KOAD',
  63: 'Spindle 𐂷 OIR',
  64: 'Honeysuckle 𐂷 UNILEAND',
  65: 'Beech 𐂷 PHAGOS',
  66: 'The Sea 𐂷 MOR',
  67: '⚁',
  68: 'The Self ᛗ MANNAZ',
  69: 'Partnership ᚷ GEBO',
  70: 'Signals ᚫ ANSUZ',
  71: 'Seperation ᛟ OTHILA',
  72: 'Strength ᚢ URUZ',
  73: 'Initiatian ᛈ PERTH',
  74: 'Constraint ᚾ NAUTHIZ',
  75: 'Fertility ᛝ INGUZ',
  76: 'Defense ᛇ EIHWAZ',
  77: 'Protection ᛉ ALGIZ',
  78: 'Posessions ᛓ FEHU',
  79: 'Joy ᚹ WUNJO',
  80: 'Harvest ᛃ JERA',
  81: 'Opening ᚲ KANO',
  82: 'Warrior ᛏ TEIWAZ',
  83: 'Growth ᛒ BERKANA',
  84: 'Movement ᛖ EHWAZ',
  85: 'Flow ᛐ LAGUZ',
  86: 'Disruption ᚺ HAGALAZ',
  87: 'Journey ᚱ RAIDO',
  88: 'Gateway ᚦ THURISAZ',
  89: 'Breakthrough ᛞ DAGAZ',
  90: 'Standstill ᛁ ISA',
  91: 'Wholeness ᛲ SOWELU',
  92: 'Unknowable  ODIN',
  93: '⚂',
  94: '🜁',
  95: '🜂',
  96: '🜃',
  97: '🜄',
  98: '⚃',
  99: '䷀',
  100: '䷁',
  101: '䷂',
  102: '䷃',
  103: '䷄',
  104: '䷅',
  105: '䷆',
  106: '䷇',
  107: '䷈',
  108: '䷉', // 10
  109: '䷊',
  110: '䷋',
  111: '䷌',
  112: '䷍',
  113: '䷎',
  114: '䷏',
  115: '䷐',
  116: '䷑',
  117: '䷒',
  118: '䷓',
  119: '䷔',
  120: '䷕',
  121: '䷖',
  122: '䷗',
  123: '䷘', // 25
  124: '䷙',
  125: '䷚',
  126: '䷛',
  127: '䷜',
  128: '䷝',
  129: '䷞',
  130: '䷟',
  131: '䷠',
  132: '䷡',
  133: '䷢',
  134: '䷣',
  135: '䷤',
  136: '䷥',
  137: '䷦',
  138: '䷧', // 40
  139: '䷨',
  140: '䷩',
  141: '䷪',
  142: '䷫',
  143: '䷬',
  144: '䷭',
  145: '䷮',
  146: '䷯',
  147: '䷰',
  148: '䷱', // 50
  149: '䷲',
  150: '䷳',
  151: '䷴',
  152: '䷵',
  153: '䷶',
  154: '䷷',
  155: '䷸',
  156: '䷹',
  157: '䷺',
  158: '䷻',
  159: '䷼',
  160: '䷽',
  161: '䷾',
  162: '䷿',
  163: '¤',
  164: '🃕',
  165: '🂢',
  166: '🃉',
  167: '🂾',
  168: '🃃',
  169: '🂣',
  170: '🃋',
  171: '🂶',
  172: '🃍',
  173: '🂮',
  174: '🃞',
  175: '🂪',
  176: 'MOONSTONE',
  177: 'LAPIS_LAZULI',
  178: 'FLOWER_AGATE',
  179: 'MOSS_AGATE',
  180: 'SHAKTI',
  181: 'SUNSTONE',
  182: 'HEMATITE',
  183: 'AQUAMARINE',
  184: 'MALACHITE',
  185: 'ARAGONITE',
  186: 'BLACK_TOURMALINE',
  187: 'TOURQUISE',
  188: 'CALCITE',
  189: 'ROSE_QUARTZ',
  190: 'FLOURITE',
  191: 'PINK_AMETHYST',
  192: 'SMOKY_AMAZONITE',
  193: 'CITRINE',
  194: 'PEACH_SELENITE',
  195: 'SUPER_SEVEN',
  196: 'LABRADORITE',
  197: 'LARIMAR',
  198: 'LACE_AGATE',
  199: 'PYRITE',
  200: 'RED_JASPER',
  201: 'APOPHYLLITE',
  202: 'OPAL',
  203: 'EMERALD',
  204: 'HERKIMER_DIAMOND',
  205: 'AZURITE',
  206: 'AMMONITE',
  207: 'DESERT_JASPER',
  208: 'SPIRIT_QUARTZ',
  209: '⚄',
  210: '☌',
  211: '⚯',
  212: '□',
  213: '♈︎',
  214: '☌',
  215: '⚯',
  216: '□',
  217: 'WOOD',
  218: 'METAL',
  219: '⇠',
  220: '⇡',
  221: '⇢',
  222: '⇣',
  223: '꩜',
  224: '❀',
  225: '𑗘',
  226: '♡',
  227: '▲',
  228: 'FRIDAY',
  229: '⚅',
  230: 'WOLF',
  231: 'CAT',
  232: 'ROOSTER',
  233: 'COW',
  234: 'BUFFALO',
  235: 'SPIDER',
  236: 'HORSE',
  237: 'SNAKE',
  238: 'FISH',
  239: 'FOX',
  240: 'BAT',
  241: 'MONKEY',
  242: 'TURTLE',
  243: 'BIRD',
  244: 'GOAT',
  245: 'MALKUTH',
  246: 'YESOD',
  247: 'HOD',
  248: 'NETZACH',
  249: 'TIPARETH',
  250: 'GEBURH',
  251: 'CHESED',
  252: 'DAATH',
  253: 'BINAH',
  254: 'CHOKMAH',
  255: 'KETER'
}

function ir(peerId: any){
  console.log(peerId)
  let spirit: any = []
  const rad = 13
  let total = 0
  if(peerId){
    // console.log(String(peerId).length)
    for(let i = 0; i < peerId.length + 1; i++) {
      if(i % rad || i == 0) {
        // console.log(peerId.charCodeAt(i))
        total += peerId.charCodeAt(i)
      } else {
        // console.log(i)
        // console.log(total)
        // console.log(library[total % 256])
        spirit.push(library[total % 256])
        total = 0
      }
    }
    // console.log(library)
    return `${spirit[0]}-${spirit[1]}-${spirit[2]}-${spirit[3]}`
  }else return null
}

async function lir(peerIdPromise: any){
  // console.log(await peerIdPromise)
  // const peerId = (await peerIdPromise).Libp2pPeerId.toB58String()
  const seedArray = (await peerIdPromise)
  // if(typeof peerId == KeyPair) {
  //   // peerId = peerId.
  // }
  // console.log(seedArray)
  await Fluence.start({
    connectTo: krasnodar[RELAY_ZONE],
    KeyPair: await KeyPair.fromEd25519SK(seedArray)
  })

  const peerId = Fluence.getStatus().peerId
  console.log('peerId')
  console.log(peerId)

  let spirit: any = []
  if(peerId){
    const rad = 13
    let total = 0
    // console.log(String(peerId).length)
    for(let i = 0; i < peerId.length + 1; i++) {
      if(i % rad || i == 0) {
        // console.log(peerId.charCodeAt(i))
        total += peerId.charCodeAt(i)
      } else {
        // console.log(i)
        // console.log(total)
        // console.log(library[total % 256])
        spirit.push(library[total % 256])
        total = 0
      }
    }
  }
  console.log('LIBRARY')
  console.log(library)
  return `${spirit[0]}-${spirit[1]}-${spirit[2]}-${spirit[3]}`
}

async function rite(setMessages: any, setAuthor: any){
  // const matter = new Matter()
      // matter.bootUp()
    // ;(await matter.direct()).reed.socket('localhost:3000', true, (io: any) => {
      // receive a message from the server
      await Fluence.start({
        connectTo: krasnodar[RELAY_ZONE],
        KeyPair: await KeyPair.fromEd25519SK((await Vault(true))!)
      })
      console.log(Fluence.getStatus().peerId)

      setAuthor(await lir(Vault(true)))


  socket.addEventListener("message", ({ data }) => {
    const packet = JSON.parse(data);
    console.log(packet)
    console.log(color)
    ++count
    setMessages((prevMessages: any) => [...prevMessages, <FeedMessage sender={count % 2 == 0} peerId={packet.content[1].from}from={ir(packet.content[1].from)} message={packet.content[1]} colorName={color} />])
    switch (packet.type) {
      case "hello from server":
        // ...
        break;
    }
  });
}

// 'use strict'
const colors = {
	"aliceblue": [240, 248, 255],

	"antiquewhite": [250, 235, 215],
	"aqua": [0, 255, 255],
	"aquamarine": [127, 255, 212],
	"azure": [240, 255, 255],
	"beige": [245, 245, 220],

	"bisque": [255, 228, 196],
	"black": [0, 0, 0],
	"blanchedalmond": [255, 235, 205],
	"blue": [0, 0, 255],
	"blueviolet": [138, 43, 226],
	"brown": [165, 42, 42],
	"burlywood": [222, 184, 135],
	"cadetblue": [95, 158, 160],

	"chartreuse": [127, 255, 0],
	"chocolate": [210, 105, 30],
	"coral": [255, 127, 80],
	"cornflowerblue": [100, 149, 237],
	"cornsilk": [255, 248, 220],
	"crimson": [220, 20, 60],
	"cyan": [0, 255, 255],
	"darkblue": [0, 0, 139],

	"darkcyan": [0, 139, 139],
	"darkgoldenrod": [184, 134, 11],
	"darkgray": [169, 169, 169],
	"darkgreen": [0, 100, 0],
	"darkgrey": [169, 169, 169],
	"darkkhaki": [189, 183, 107],
	"darkmagenta": [139, 0, 139],
	"darkolivegreen": [85, 107, 47],
	"darkorange": [255, 140, 0],
	"darkorchid": [153, 50, 204],
	"darkred": [139, 0, 0],
	"darksalmon": [233, 150, 122],
	"darkseagreen": [143, 188, 143],
	"darkslateblue": [72, 61, 139],
	"darkslategray": [47, 79, 79],
	"darkslategrey": [47, 79, 79],
	"darkturquoise": [0, 206, 209],
	"darkviolet": [148, 0, 211],
	"deeppink": [255, 20, 147],
	"deepskyblue": [0, 191, 255],
	"dimgray": [105, 105, 105],
	"dimgrey": [105, 105, 105],
	"dodgerblue": [30, 144, 255],
	"firebrick": [178, 34, 34],

	"floralwhite": [255, 250, 240],
	"forestgreen": [34, 139, 34],
	"fuchsia": [255, 0, 255],
	"gainsboro": [220, 220, 220],

	"ghostwhite": [248, 248, 255],
	"gold": [255, 215, 0],
	"goldenrod": [218, 165, 32],
	"gray": [128, 128, 128],
	"green": [0, 128, 0],
	"greenyellow": [173, 255, 47],
	"grey": [128, 128, 128],
	"honeydew": [240, 255, 240],

	"hotpink": [255, 105, 180],
	"indianred": [205, 92, 92],

	"indigo": [75, 0, 130],
	"ivory": [255, 255, 240],
	"khaki": [240, 230, 140],

	"lavender": [230, 230, 250],

	"lavenderblush": [255, 240, 245],
	"lawngreen": [124, 252, 0],
	"lemonchiffon": [255, 250, 205],
	"lightblue": [173, 216, 230],
	"lightcoral": [240, 128, 128],
	"lightcyan": [224, 255, 255],
	"lightgoldenrodyellow": [250, 250, 210],
	"lightgray": [211, 211, 211],
	"lightgreen": [144, 238, 144],
	"lightgrey": [211, 211, 211],
	"lightpink": [255, 182, 193],
	"lightsalmon": [255, 160, 122],
	"lightseagreen": [32, 178, 170],
	"lightskyblue": [135, 206, 250],
	"lightslategray": [119, 136, 153],
	"lightslategrey": [119, 136, 153],
	"lightsteelblue": [176, 196, 222],
	"lightyellow": [255, 255, 224],
	"lime": [0, 255, 0],
	"limegreen": [50, 205, 50],
	"linen": [250, 240, 230],
	"magenta": [255, 0, 255],
	"maroon": [128, 0, 0],
	"mediumaquamarine": [102, 205, 170],
	"mediumblue": [0, 0, 205],
	"mediumorchid": [186, 85, 211],
	"mediumpurple": [147, 112, 219],
	"mediumseagreen": [60, 179, 113],
	"mediumslateblue": [123, 104, 238],
	"mediumspringgreen": [0, 250, 154],
	"mediumturquoise": [72, 209, 204],
	"mediumvioletred": [199, 21, 133],
	"midnightblue": [25, 25, 112],
	"mintcream": [245, 255, 250],
	"mistyrose": [255, 228, 225],
	"moccasin": [255, 228, 181],
	"navajowhite": [255, 222, 173],
	"navy": [0, 0, 128],
	"oldlace": [253, 245, 230],
	"olive": [128, 128, 0],
	"olivedrab": [107, 142, 35],
	"orange": [255, 165, 0],
	"orangered": [255, 69, 0],
	"orchid": [218, 112, 214],
	"palegoldenrod": [238, 232, 170],
	"palegreen": [152, 251, 152],
	"paleturquoise": [175, 238, 238],
	"palevioletred": [219, 112, 147],
	"papayawhip": [255, 239, 213],
	"peachpuff": [255, 218, 185],
	"peru": [205, 133, 63],
	"pink": [255, 192, 203],
	"plum": [221, 160, 221],
	"powderblue": [176, 224, 230],
	"purple": [128, 0, 128],
	"rebeccapurple": [102, 51, 153],
	"red": [255, 0, 0],
	"rosybrown": [188, 143, 143],
	"royalblue": [65, 105, 225],
	"saddlebrown": [139, 69, 19],
	"salmon": [250, 128, 114],
	"sandybrown": [244, 164, 96],
	"seagreen": [46, 139, 87],
	"seashell": [255, 245, 238],
	"sienna": [160, 82, 45],
	"silver": [192, 192, 192],
	"skyblue": [135, 206, 235],
	"slateblue": [106, 90, 205],
	"slategray": [112, 128, 144],
	"slategrey": [112, 128, 144],
	"snow": [255, 250, 250],
	"springgreen": [0, 255, 127],
	"steelblue": [70, 130, 180],
	"tan": [210, 180, 140],
	"teal": [0, 128, 128],
	"thistle": [216, 191, 216],
	"tomato": [255, 99, 71],
	"turquoise": [64, 224, 208],
	"violet": [238, 130, 238],
	"wheat": [245, 222, 179],
	"white": [255, 255, 255],
	"whitesmoke": [245, 245, 245],
	"yellow": [255, 255, 0],
	"yellowgreen": [154, 205, 50]
};

var index = [];

const copyToClipboard = (text: string) => {
  navigator.clipboard.writeText(text);
};

let messageCache: any = null
function Chat(props: any){

  const colorRandom = async () => {
    // in order to achive technospiritual symbiois, 
    // a hypothesis is to get a whole conversation in the same color through organic means. 
    // if this is possble in a time frame, maybe it's possible. 
    // same exerience with hypercore, urbit, ethereum, ϕ(c○smos), etc.

    // laying floors, like a random trick for the quick house click;
    // there are streets, and fleets, on delegate weeks;
    // withdraw, fin-tall, winning, perusing, and it's draws;
    // as a glazing on our pets, what halfs but than a pit pat paddy wack, giva dog a bone;
    // laying down the summer deck via the xmas light, the kilning gifts and wrist poap;
    // rolling up in holland, appollonian status quo; 
    // revert back, jump condition ethtoronto dice calls; 
    // bogota via the relays, the flu tarot ways;
    // give it a-week, a complete diode on the flyy tally ode;

    const colorsSet = ['classless', 
    'green',
    'bisque', 
    'cadetblue',
    'darkblue',
    'floralwhite',
    'gainsboro',
    'hotpink',
    'lavender']
    color = colorsSet[Math.floor(Math.random() * 9)]
    // setColor(colorsSet[Math.floor(Math.random() * 9)])
  }

  return(
    <>
      <div className="channel-feed__body">
              
              {props.messages}

            </div>
             <div className="channel-feed__footer">
              <form
                className="channel-message-form"
                action="#"
                
                onSubmit={(e) => e.preventDefault()}
              >
                <div className="form-group">
                  <label className="form-label">
                    Message
                  </label>
                  <div className="form-control">
                    <textarea
                      id="message"
                      className="form-control"
                      name="message"
                      onChange={(e) => {
                        props.setMessage(e.target.value)
                        messageCache = e.target.value
                        console.log(e.target.value)
                        console.log(props.message)
                      }}
                    ></textarea>
                  </div>
                </div>
                <div className="form-footer">
                  <Button size="xl" variant="primary" message={props.message}>
                    Send
                  </Button>
                  <Button size="xl" variant="secondary" radio={true} colorRandom={colorRandom} >
                    color
                  </Button>
                </div>
              </form>
            </div> 
    </>
  )
}

function About(){
  return(<>
    <h1>⊛</h1>
    <p>chatabout explores the potential of p2p group chat</p>
    <p>messages are only read live in the interface, and deleted after each session unless peers would like to save, done by the moderator</p>
    <p>peers can pull a tarot card to orient the conversation</p>
    <p>peers can copy messages for personal keeping</p>
    <p>or, peers can checkout nfts</p>
    <h1>⊛</h1>
  </>)
}
const Compass = (props: any, setRenderer: any, message: any, setMessage: any, messages: any, setMessages: any) => {
  let needle;
  // like a quilt
  switch(props){
    case 1:
      needle = <Chat setRenderer={setRenderer} messages={messages} setMessage={setMessage}/>
      break;
    case 2:
      needle = <About/>
      break;
    case 3:
      needle = <p>NFTs</p>
      break;
    default:
      needle = <h4>404</h4>
  }

  return needle
}

function Station(props: any){
  return(<>
  <a className="button button--default" onClick={() => {
    props.setDirect(props.channel)
    props.setRenderer(1)
    copyToClipboard(props.icon)
    }}>
    {/* ☎ */}
    {props.icon}
  </a>
  </>)
}
// hack, sorry
// const [color, setColor] = useState<any>(null)
let color: string = 'classless'
let test: any = 0
function App() {
  const [onInit, setOnInit] = useState<any>(false)
  const [messages, setMessages] = useState<any>([])
  const [message, setMessage] = useState<any>(null)
  const [author, setAuthor] = useState<any>()
  const [renderer, setRenderer] = useState(1)
  const [direct, setDirect] = useState('☎ General')
  const [channels, setChannels] = useState<any>()
  const [dial, setDial] = useState<any>(false)
  // const { connect } = useConnect({
  //   connector: new InjectedConnector(),
  // })
  // const { address, isConnected } = useAccount()

  // const [
  // const [color, setColor] = useState<any>(null)

  const colorRandom = async () => {
    // in order to achive technospiritual symbiois, 
    // a hypothesis is to get a whole conversation in the same color through organic means. 
    // if this is possble in a time frame, maybe it's possible. 
    // same exerience with hypercore, urbit, ethereum, ϕ(c○smos), etc.

    // laying floors, like a random trick for the quick house click;
    // there are streets, and fleets, on delegate weeks;
    // withdraw, fin-tall, winning, perusing, and it's draws;
    // as a glazing on our pets, what halfs but than a pit pat paddy wack, giva dog a bone;
    // laying down the summer deck via the xmas light, the kilning gifts and wrist poap;
    // rolling up in holland, appollonian status quo; 
    // revert back, jump condition ethtoronto dice calls; 
    // bogota via the relays, the flu tarot ways;
    // give it a-week, a complete diode on the flyy tally ode;

    const colorsSet = ['classless', 
    'green',
    'bisque', 
    'cadetblue',
    'darkblue',
    'floralwhite',
    'gainsboro',
    'hotpink',
    'lavender']
    color = colorsSet[Math.floor(Math.random() * 9)]
    // setColor(colorsSet[Math.floor(Math.random() * 9)])
  }


  const rotator = async () => {
    // await connect()

    // const provider = new ethers.providers.Web3Provider(window.ethereum)
    // const contract = new ethers.Contract('0x33EeCbf908478C10614626A9D304bfe18B78DD73', eclipticABI, provider)
    
    
    // for(let i = 0; i < 4000000000;i++){
    //   if(address == await contract.ownerOf(i)){
    //     console.log(ob.hex2patq(i))
    //   }
    // }
    // console.log()
    test++
    if(test == 3) test = 0
    console.log('rotate')
    // console.log(address)
    // const ens = await provider.lookupAddress(address as any)
    // console.log(ens)
  }

  const setMatter = () => {
    loadChannels()
    setDial(!dial)
  }

  const loadChannels = () => {
    console.log('loading channels')

    const arena = new Arena({ accessToken: "alwkXa6QcO6PTvHXns8cQTJgMy89URJqm6sS1ogGJSM" });

    arena
      .channel("is-a-memory-a-snowflake")
      .get()
      .then((chan: any) => {
        chan.contents.map((item: any) => {
          console.log(item.content.split(' '));
        });
      })
      .catch((err: any) => console.log(err));

    // const stationSet = [['☎', 'General'],['X','Ouroboros'],['☎', 'General'],['X','Ouroboros'],['☎', 'General'],['X','Ouroboros'],['☎', 'General'],['X','Ouroboros'],['☎', 'General'],['X','Ouroboros'],['☎', 'General'],['X','Ouroboros'],['☎', 'General'],['X','Ouroboros'],['☎', 'General'],['X','Ouroboros'],['☎', 'General'],['X','Ouroboros'],['☎', 'General'],['X','Ouroboros'],['☎', 'General'],['X','Ouroboros'],['☎', 'General'],['X','Ouroboros'],['☎', 'General'],['X','Ouroboros']]
    const stationSet = [['𐂷','tree'],
      ['⛤', 'commerce'],
      ['☮', 'music'],
      ['♻', 'baths'],
      ['🜃', 'living'],
      ['☘', 'study'],
      ['꩜', 'education'],
      ['⊛', 'chatabout'],
      ['☸', 'art'],
      ['⛮', 'clock'],
      ['⛐', 'roads']]
    const stationsToSet = stationSet.map((el) => {
      // ioi harmonizing station function for collective harmony
      return <Station channel={`${el[0]}${el[1]}`} icon={el[0]} setDirect={setDirect} setRenderer={setRenderer}/>
    })
    setChannels(stationsToSet)
  }

  useEffect(() => {
    if(!onInit){
      setOnInit(true)
      rite(setMessages, setAuthor)
      loadChannels()
      
      // const cheerio = require('cheerio');
      // const $ = cheerio.load('<h2 class="title">Hello world</h2>');

      // $('h2.title').text('Hello there!');
      // $('h2').addClass('welcome');

      // $.html();

      // build the index
      for (var x in colors) {
        index.push(x);
      }
    }
  }, [messages, color])


  return (
    <div className="app-skeleton">
      <header className="app-header">
        <div className="app-header__anchor">
          <span className="app-header__anchor__text">chatabout</span>
        </div>
        <nav>
          {/* <ul className="nav">
            {FIXTURES.headerMenu.map((navItem, navItemIndex) => (
              <NavItem key={navItemIndex} navItem={navItem} />
            ))}
          </ul> */}
        </nav>
        <div />
      </header>
      <br/>
      <br/>
      <br/>
      <br/>
      <br/>

      <div className="app-main" style={{width: '30%', margin: 'auto'}}>
          <div className="channel-feed">
          <div className="segment-topbar">
              <div className="segment-topbar__aside">
                <div className="button-toolbar__scroll">
                  {dial ? channels : null}
                </div>
              </div>
            </div>
            <div className="segment-topbar">
              <div className="segment-topbar__header">
                <TextOverline className="segment-topbar__overline">
                {author} · 
                </TextOverline>
                <TextOverline className="segment-topbar__overline">
                  commands 
                  - /tarot
                </TextOverline>
                <TextHeading4 className="segment-topbar__title">
                  <ChannelLink name={direct} />
                </TextHeading4>
              </div>
              <div className="segment-topbar__aside">
                <div className="button-toolbar">
                  <a className="button button--default" onClick={() => {
                    setDirect('☎ General')
                    setRenderer(1)
                    }}>
                    ☎
                  </a>
                  <a className="button button--default" onClick={() => {
                    setMatter()
                    setDirect('☂ NFTs')
                    setRenderer(3)
                  }}>
                    ☂
                  </a>
                  <a className="button button--default" onClick={() =>{
                    setDirect('⚑ about')
                    setRenderer(2)
                  }}>
                    {/* <IconFeedMute className="button__icon" /> */}
                    ⚑
                  </a>
                  &nbsp;&nbsp;
                  {/* <a className="button button--default">
                    <IconFeedSettings className="button__icon" />
                  </a> */}
                  <a className="button button--default" onClick={() => {
                      rotator()
                    }}>
                    <IconMenuMor className="button__icon"/>
                  </a>
                </div>
              </div>
            </div>
            
            {Compass(renderer, setRenderer, message, setMessage, messages, setMessages)}
          </div>
        </div>
    </div>
  );
}


// function NavSection({ children, renderTitle }) {
//   return (
//     <div className="nav-section">
//       <div className="nav-section__header">
//         {renderTitle({ className: "nav-section__title" })}
//       </div>
//       <div className="nav-section__body">{children}</div>
//     </div>
//   );
// }

let tarot = [
  ['The Fool','https://www.trustedtarot.com/img/cards/the-fool.png'],
  ['The Magician','https://www.trustedtarot.com/img/cards/the-magician.png'],
  ['The High Priestess','https://www.trustedtarot.com/img/cards/the-high-priestess.png'],
  ['The Empress','https://www.trustedtarot.com/img/cards/the-empress.png'],
  ['The Emperor','https://www.trustedtarot.com/img/cards/the-emperor.png'],
  ['The Hierophant','https://www.trustedtarot.com/img/cards/the-heirophant.png'],
  ['The Lovers','https://www.trustedtarot.com/img/cards/the-lovers.png'],
  ['The Chariot','https://www.trustedtarot.com/img/cards/the-chariot.png'],
  ['Fortitude','https://www.trustedtarot.com/img/cards/strength.png'],
  ['The Hermit','https://www.trustedtarot.com/img/cards/the-hermit.png'],
  ['Wheel Of Fortune','https://www.trustedtarot.com/img/cards/wheel-of-fortune.png'],
  ['Justice','https://www.trustedtarot.com/img/cards/justice.png'],
  ['The Hanged Man','https://www.trustedtarot.com/img/cards/the-hanged-man.png'],
  ['Death','https://www.trustedtarot.com/img/cards/death.png'],


  ['Temperance','https://www.trustedtarot.com/img/cards/temperance.png'],
  ['The Devil','https://www.trustedtarot.com/img/cards/the-devil.png'],
  ['The Tower','https://www.trustedtarot.com/img/cards/the-tower.png'],
  ['The Star','https://www.trustedtarot.com/img/cards/the-star.png'],
  ['The Moon','https://www.trustedtarot.com/img/cards/the-moon.png'],
  ['The Sun','https://www.trustedtarot.com/img/cards/the-sun.png'],
  ['Judgement','https://www.trustedtarot.com/img/cards/judgement.png'],
  ['The World','https://www.trustedtarot.com/img/cards/the-world.png'],


  ['King of Cups','https://www.trustedtarot.com/img/cards/king-of-cups.png'],
  ['Queen of Cups','https://www.trustedtarot.com/img/cards/queen-of-cups.png'],
  ['Knight of Cups','https://www.trustedtarot.com/img/cards/knight-of-cups.png'],
  ['Page of Cups','https://www.trustedtarot.com/img/cards/page-of-cups.png'],
  ['X of Cups','https://www.trustedtarot.com/img/cards/ten-of-cups.png'],
  ['IX of Cups','https://www.trustedtarot.com/img/cards/nine-of-cups.png'],
  ['VIII of Cups','https://www.trustedtarot.com/img/cards/eight-of-cups.png'],
  ['VII of Cups','https://www.trustedtarot.com/img/cards/seven-of-cups.png'],
  ['VI of Cups','https://www.trustedtarot.com/img/cards/six-of-cups.png'],
  ['V of Cups','https://www.trustedtarot.com/img/cards/five-of-cups.png'],
  ['IV of Cups','https://www.trustedtarot.com/img/cards/four-of-cups.png'],
  ['III of Cups','https://www.trustedtarot.com/img/cards/three-of-cups.png'],
  ['II of Cups','https://www.trustedtarot.com/img/cards/two-of-cups.png'],
  ['Ace of Cups','https://www.trustedtarot.com/img/cards/ace-of-cups.png'],
  ['King of Swords','https://www.trustedtarot.com/img/cards/king-of-swords.png'],
  ['Queen of Swords','https://www.trustedtarot.com/img/cards/queen-of-swords.png'],
  ['Knight of Swords','https://www.trustedtarot.com/img/cards/knight-of-swords.png'],
  ['Page of Swords','https://www.trustedtarot.com/img/cards/page-of-swords.png'],
  ['X of Swords','https://www.trustedtarot.com/img/cards/ten-of-swords.png'],
  ['IX of Swords','https://www.trustedtarot.com/img/cards/nine-of-swords.png'],
  ['VIII of Swords','https://www.trustedtarot.com/img/cards/eight-of-swords.png'],
  ['VII of Swords','https://www.trustedtarot.com/img/cards/seven-of-swords.png'],
  ['VI of Swords','https://www.trustedtarot.com/img/cards/six-of-swords.png'],
  ['V of Swords','https://www.trustedtarot.com/img/cards/five-of-swords.png'],
  ['IV of Swords','https://www.trustedtarot.com/img/cards/four-of-swords.png'],
  ['III of Swords','https://www.trustedtarot.com/img/cards/three-of-swords.png'],
  ['II of Swords','https://www.trustedtarot.com/img/cards/two-of-swords.png'],
  ['Ace of Swords','https://www.trustedtarot.com/img/cards/ace-of-swords.png'],
  ['King of Wands','https://www.trustedtarot.com/img/cards/king-of-wands.png'],
  ['Queen of Wands','https://www.trustedtarot.com/img/cards/queen-of-wands.png'],
  ['Knight of Wands','https://www.trustedtarot.com/img/cards/knight-of-wands.png'],
  ['Page of Wands','https://www.trustedtarot.com/img/cards/page-of-wands.png'],
  ['X of Wands','https://www.trustedtarot.com/img/cards/ten-of-wands.png'],
  ['IX of Wands','https://www.trustedtarot.com/img/cards/nine-of-wands.png'],
  ['VIII of Wands','https://www.trustedtarot.com/img/cards/eight-of-wands.png'],
  ['VII of Wands','https://www.trustedtarot.com/img/cards/seven-of-wands.png'],
  ['VI of Wands','https://www.trustedtarot.com/img/cards/six-of-wands.png'],
  ['V of Wands','https://www.trustedtarot.com/img/cards/five-of-wands.png'],
  ['IV of Wands','https://www.trustedtarot.com/img/cards/four-of-wands.png'],
  ['III of Wands','https://www.trustedtarot.com/img/cards/three-of-wands.png'],
  ['II of Wands','https://www.trustedtarot.com/img/cards/two-of-wands.png'],
  ['Ace of Wands','https://www.trustedtarot.com/img/cards/ace-of-wands.png'],
  ['King of Pentacles','https://www.trustedtarot.com/img/cards/king-of-pentacles.png'],
  ['Queen of Pentacles','https://www.trustedtarot.com/img/cards/queen-of-pentacles.png'],
  ['Knight of Pentacles','https://www.trustedtarot.com/img/cards/knight-of-pentacles.png'],
  ['Page of Pentacles','https://www.trustedtarot.com/img/cards/page-of-pentacles.png'],
  ['X of Pentacles','https://www.trustedtarot.com/img/cards/ten-of-pentacles.png'],
  ['IX of Pentacles','https://www.trustedtarot.com/img/cards/nine-of-pentacles.png'],
  ['VIII of Pentacles','https://www.trustedtarot.com/img/cards/eight-of-pentacles.png'],
  ['VII of Pentacles','https://www.trustedtarot.com/img/cards/seven-of-pentacles.png'],
  ['VI of Pentacles','https://www.trustedtarot.com/img/cards/six-of-pentacles.png'],
  ['V of Pentacles','https://www.trustedtarot.com/img/cards/five-of-pentacles.png'],
  ['IV of Penatcles','https://www.trustedtarot.com/img/cards/four-of-pentacles.png'],
  ['III of Pentacles','https://www.trustedtarot.com/img/cards/three-of-pentacles.png'],
  ['II of Pentacles','https://www.trustedtarot.com/img/cards/two-of-pentacles.png'],
  ['Ace of Pentacles','https://www.trustedtarot.com/img/cards/ace-of-pentacles.png'],
]

let oneCard: any = null
let twoCard:any = null
let threeCard: any = null
function oneOf(i: any) {
    let cards = [oneCard,twoCard,threeCard]
    // let cards = [49,27,13]
    for(let j = 0; j < cards.length; j++) {
        if (cards[j] != null && cards[j] == i){
            return false;
        }
    }
    return true
}

const matter = async (peerId: any, deckNumeric: any, compute = 'φ') => {
  let number = 0;
  if(compute == '~'){
    // looped, 
    // computers, seeded from card shared secret
  }else {
    console.log(peerId)
    console.log(deckNumeric)
    // const relayTime = await getRelayTime(peerId)
    const relayTime = Date.now()

    console.log('relaytime', relayTime)
    // if(oneCard != null &&oneCard != null &&oneCard != null) {alert('3_MAX_TAROTS_REACHED'); return 100}
    // number = Math.floor(Array.from((Array(relayTime % deckNumeric).keys()).filter().reduce((x,y) => x + Math.abs(Math.tan(y)))%deckNumeric)
    number = Math.floor((Array.from(Array(relayTime % deckNumeric).keys()).filter((i) => {console.log(oneOf(i)); return oneOf(i)})).reduce((x,y) => x + Math.abs(Math.tan(y)))%deckNumeric)
  }
  return number
}

function FeedMessage(props: any) {
  const [onInit, seOnInit] = useState<any>()
  const [card, setCard] = useState<any>()
  console.log(props)
  // const ran = Math.floor(Math.random() * 48)
  const border = `1px solid rgb(${colors['aliceblue'][0]}, ${colors['aliceblue'][1]}, ${colors['aliceblue'][2]}) !important`
  const color = `rgb(${colors['aliceblue'][0]}, ${colors['aliceblue'][1]}, ${colors['aliceblue'][2]}) !important`
  console.log(border)
  console.log(color)
  console.log(props.peerId)
  console.log(Fluence.getStatus().peerId)
  const pullForFolk = async () => {
    const ran = Math.floor(Math.random()*78)
    // const relayTime = await getRelayTime(peerId)
    const number = await matter(Fluence.getStatus().relayPeerId, 78)
    // if(oneCard == null) oneCard = number
    // else if(twoCard == null) twoCard = number
    // else if(threeCard == null) threeCard = number

    // if(number != 100) setCard(<img src={tarot[number][1]}/>)
  }
  // const className = "classless"
  useEffect(() => {
    if(!onInit){
      if(props.message.card == '/tarot'){
        pullForFolk()
      }
      seOnInit(true)
    }
  }, [card])

  return (
    <div className="message">
      <p onClick={() => copyToClipboard(`${props.message.card} | said by ${ir(Fluence.getStatus().peerId)}`)} className={props.colorName} style={{ cursor: 'pointer', textAlign: props.peerId == Fluence.getStatus().peerId ? 'right' : 'left'}}>⊛</p>
      <div className="message__body" style={{border: `1px solid rgb(${colors['aliceblue'][0]}, ${colors['aliceblue'][1]}, ${colors['aliceblue'][2]}) !important`, color: color}}>
        <div style={{border: border, color: color}}>
          {props.message.card}
          {props.message.card == '/tarot' ? card : null}
        </div>
      </div>
      <div className="message__footer">
        <span className="message__authoring">{props.from}</span>
        &nbsp;&nbsp;&nbsp;
        &nbsp;&nbsp;&nbsp;
        &nbsp;&nbsp;&nbsp;
        &nbsp;&nbsp;&nbsp;
        {(new Date(props.message.time)).toTimeString()}
        {/* {props.message.time} */}
      </div>
    </div>
  );
}

// function ChannelNav({ activeChannel = null, channels = [] }) {
//   return (
//     <ul className="nav">
//       {channels.map((channel) => (
//         <li className="nav__item">
//           <a
//             className={`nav__link ${
//               activeChannel && activeChannel.id === channel.id
//                 ? "nav__link--active"
//                 : ""
//             }`}
//             href="#"
//           >
//             <ChannelLink {...channel}>{'/'}</ChannelLink>
//           </a>
//         </li>
//       ))}
//     </ul>
//   );
// }

// function ConversationNav({ activeConversation = null, conversations = [] }) {
//   return (
//     <ul className="nav">
//       {conversations.map((convo) => (
//         <li className="nav__item">
//           <a
//             className={`nav__link ${
//               activeConversation && activeConversation.id === convo.id
//                 ? "nav__link--active"
//                 : ""
//             }`}
//             href="#"
//           >
//             <ConversationLink conversation={convo} />
//           </a>
//         </li>
//       ))}
//     </ul>
//   );
// }

function ChannelLink(props: any) {
  return (
    <span
      className={`channel-link ${
        props.unread > 0 ? "conversation-link--unread" : ""
      }`}
    >
      <span className="channel-link__icon">#</span>
      <span className="channel-link__element">{props.name}</span>

      {props.unread > 0 && (
        <span className="channel-link__element">
          <Badge>{props.unread}</Badge>
        </span>
      )}
    </span>
  );
}

// function ConversationLink(props: any) {
//   return (
//     <span
//       className={`conversation-link ${
//         props.conversation.isOnline ? "conversation-link--online" : ""
//       } ${props.conversation.unread > 0 ? "conversation-link--unread" : ""}`}
//     >
//       {conversation.members && conversation.members.length > 2 ? (
//         <span className="conversation-link__icon" />
//       ) : (
//         <span className="conversation-link__icon" />
//       )}

//       <span className="conversation-link__element">{conversation.name}</span>

//       {conversation.unread > 0 && (
//         <span className="conversation-link__element">
//           <Badge>{conversation.unread}</Badge>
//         </span>
//       )}
//     </span>
//   );
// }

async function Vault(fromStore = false) {
  // const keyString = localStorage.getItem('⚂')
  const keyString = localStorage.getItem('⚅')

  // console.log(keyString)
  // console.log(keyString == null)
  // console.log(!fromStore)

  if(keyString == null || !fromStore) {
    const keyString = (await KeyPair.randomEd25519()).toEd25519PrivateKey()
    localStorage.setItem('⚂', String(keyString)) // 3 is dox
    return keyString
  } else if(fromStore) {
    // console.log(keyString)
    return new Uint8Array(keyString.split(',').map((num) => Number(num)))

  }
  // else return await KeyPair.fromEd25519SK(new Uint8Array(keyString.split(',').map((num) => Number(num))))
}

function Badge(props: any) {
  return <span className="badge">{props.children}</span>;
}

function Button(props: any){
  
  const send = async () => {
    if (!Fluence.getStatus().isConnected) {
        return;
    }
    console.log('testing')
    console.log(Fluence.getStatus().peerId ?? '')

    // addDeck
    const ad = await addMessage(Fluence.getStatus().peerId ?? '',PEER_ID, krasnodar[RELAY_ZONE].multiaddr.split('/p2p/')[1], "0x", "signature", "n3pthora", [messageCache])
    console.log(ad)
  }

  const color = async () => {
    console.log('color')
    props.colorRandom()
  }

  return (
    <button
      onClick={async () => !props.radio ? send() : color()}
      className={`button ${props.variant ? `button--${props.variant}` : ""} ${
        props.size ? `button--size-${props.size}` : ""
      }`}
      type={props.type}
    >
      <span className="button__content">{props.children}</span>
    </button>
  );
}

// function Pad({ children, renderCap = null }) {
//   return (
//     <div className="pad">
//       <div className="pad__body">{children}</div>
//     </div>
//   );
// }

// function NavItem({ navItem }) {
//   return (
//     <li className="nav__item">
//       <a
//         className={`nav__link ${navItem.isActive ? "nav__link--active" : ""}`}
//         href="#"
//       >
//         <span className="nav__link__element">{navItem.text}</span>
//         {navItem.notificationCount > 0 && (
//           <span className="nav__link__element">
//             <Badge>{navItem.notificationCount}</Badge>
//           </span>
//         )}
//       </a>
//     </li>
//   );
// }

function MakeTextBase(classNameDefault: any, $asDefault: any) {
  return (props: any) => {
    const AsComponent = props.$as || $asDefault;

    return (
      <AsComponent className={`${classNameDefault} ${props.className}`}>
        {props.children}
      </AsComponent>
    );
  };
}

// const TextHeading1 = MakeTextBase("text-heading1", "h1");
// const TextHeading2 = MakeTextBase("text-heading2", "h2");
// const TextHeading3 = MakeTextBase("text-heading3", "h3");
const TextHeading4 = MakeTextBase("text-heading4", "h4");
// const TextHeading5 = MakeTextBase("text-heading5", "h5");
// const TextHeading6 = MakeTextBase("text-heading6", "h6");
// const TextParagraph1 = MakeTextBase("text-paragraph1", "p");
const TextOverline = MakeTextBase("segment-topbar__overline", "span");

function MakeIcon(svg: any) {
  return (props: any) => (
    <svg
      className={props.className}
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 24 24"
    >
      {svg}
    </svg>
  );
}

const IconFeedMute = MakeIcon(
  <path d="M18 9.5c2.481 0 4.5 1.571 4.5 3.503 0 1.674-1.703 3.48-4.454 3.48-.899 0-1.454-.156-2.281-.357-.584.358-.679.445-1.339.686.127-.646.101-.924.081-1.56-.583-.697-1.007-1.241-1.007-2.249 0-1.932 2.019-3.503 4.5-3.503zm0-1.5c-3.169 0-6 2.113-6 5.003 0 1.025.37 2.032 1.023 2.812.027.916-.511 2.228-.997 3.184 1.302-.234 3.15-.754 3.989-1.268.709.173 1.388.252 2.03.252 3.542 0 5.954-2.418 5.954-4.98.001-2.906-2.85-5.003-5.999-5.003zm-.668 6.5h-1.719v-.369l.938-1.361v-.008h-.869v-.512h1.618v.396l-.918 1.341v.008h.95v.505zm3.035 0h-2.392v-.505l1.306-1.784v-.011h-1.283v-.7h2.25v.538l-1.203 1.755v.012h1.322v.695zm-10.338 9.5c1.578 0 2.971-1.402 2.971-3h-6c0 1.598 1.45 3 3.029 3zm.918-7.655c-.615-1.001-.947-2.159-.947-3.342 0-3.018 2.197-5.589 5.261-6.571-.472-1.025-1.123-1.905-2.124-2.486-.644-.374-1.041-1.07-1.04-1.82v-.003c0-1.173-.939-2.123-2.097-2.123s-2.097.95-2.097 2.122v.003c.001.751-.396 1.446-1.041 1.82-4.667 2.712-1.985 11.715-6.862 13.306v1.749h9.782c.425-.834.931-1.764 1.165-2.655zm-.947-15.345c.552 0 1 .449 1 1 0 .552-.448 1-1 1s-1-.448-1-1c0-.551.448-1 1-1z" />
);

const IconFeedSettings = MakeIcon(
  <path d="M6 16h-6v-3h6v3zm-2-5v-10h-2v10h2zm-2 7v5h2v-5h-2zm13-7h-6v-3h6v3zm-2-5v-5h-2v5h2zm-2 7v10h2v-10h-2zm13 3h-6v-3h6v3zm-2-5v-10h-2v10h2zm-2 7v5h2v-5h-2z" />
);

const IconMenuMor = MakeIcon(
  <path d="M12 18c1.657 0 3 1.343 3 3s-1.343 3-3 3-3-1.343-3-3 1.343-3 3-3zm0-9c1.657 0 3 1.343 3 3s-1.343 3-3 3-3-1.343-3-3 1.343-3 3-3zm0-9c1.657 0 3 1.343 3 3s-1.343 3-3 3-3-1.343-3-3 1.343-3 3-3z" />
);

// const IconFeedAdd = MakeIcon(
//   <path d="M24 10h-10v-10h-4v10h-10v4h10v10h4v-10h10z" />
// );

// const IconSearchSubmit = MakeIcon(
//   <path d="M21.172 24l-7.387-7.387c-1.388.874-3.024 1.387-4.785 1.387-4.971 0-9-4.029-9-9s4.029-9 9-9 9 4.029 9 9c0 1.761-.514 3.398-1.387 4.785l7.387 7.387-2.828 2.828zm-12.172-8c3.859 0 7-3.14 7-7s-3.141-7-7-7-7 3.14-7 7 3.141 7 7 7z" />
// );

// const IconShop = MakeIcon(
//   <path d="M16.53 7l-.564 2h-15.127l-.839-2h16.53zm-14.013 6h12.319l.564-2h-13.722l.839 2zm5.983 5c-.828 0-1.5.672-1.5 1.5 0 .829.672 1.5 1.5 1.5s1.5-.671 1.5-1.5c0-.828-.672-1.5-1.5-1.5zm11.305-15l-3.432 12h-13.017l.839 2h13.659l3.474-12h1.929l.743-2h-4.195zm-6.305 15c-.828 0-1.5.671-1.5 1.5s.672 1.5 1.5 1.5 1.5-.671 1.5-1.5c0-.828-.672-1.5-1.5-1.5z" />
// );


const FIXTURES = {
  headerMenu: [
    { notificationCount: 0, text: "Home" },
    { isActive: true, notificationCount: 11, text: "Messages" },
    { notificationCount: 0, text: "Shop" },
    { notificationCount: 0, text: "Map" },
    { notificationCount: 0, text: "Files" }
  ],
  feed: [
    { id: "5ba5", name: "Afterlife", unread: 3 },
    { id: "4f22", name: "NCPD-Gigs" },
    { id: "fee9", name: "Pacifica" },
    { id: "a0cc", name: "Watson" },
    { id: "dee3", name: "_T_SQUAD", isPrivate: true, unread: 2 }
  ],
  conversation: [
    {
      id: "cc23",
      isOnline: true,
      unread: 5,
      name: "Rogue Amendiares"
    },
    { id: "95b4", isOnline: true, name: "Takemura", unread: 1 },
    { id: "10cf", name: "Wakado O., Regina Jones" },
    { id: "e466", name: "Dexter DeShawn" },
    { id: "ca0b", name: "Megabuilding H10 Administration" }
  ],
  messages: [
    {
      id: "fd0cf",
      content:
        "I got a gig lined up in Watson, no biggie. If you prove useful, expect more side gigs coming your way. I need a half-decent netrunner. Hit me up, provide credentials, eddies on completion.",
      dateTime: "2077-10-09T11:04:57Z",
      author: {
        id: "d12c",
        name: "V.M. Vargas"
      }
    }
  ]
};

// render(<App />, document.getElementById("root"));


export default App;
