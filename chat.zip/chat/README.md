# chat
chatabout nothing

tarot commands for a group chat interface

combine with fluenceseed v2 federated aqua node
